﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary
{
    /// <summary>
    /// Класс для работы с удалением рецептов
    /// </summary>
    public class ExecuteDeleteRecipe
    {
        /// <summary>
        /// Удаляет рецепт
        /// </summary>
        /// <param name="recipeList"></param>
        public void DeleteRecipe(ref RecipeList recipeList)
        {
            ExecutePrintAllRecipe executePrintAllRecipe = new ExecutePrintAllRecipe();
            if (ServiceClass.isEmptyRecipeList(ref recipeList))
            {
                return;
            }
            executePrintAllRecipe.PrintAllecipe(ref recipeList);
            Console.WriteLine("Введите название рецепта которое хотите удалить: ");
            string recipeName = ServiceClass.GetValidName();
            bool flag = false;
            foreach (Recipe recipe in recipeList.Recipes)
            {
                if (recipe.Name == recipeName)
                {
                    recipeList.Recipes.Remove(recipe);
                    flag = true;
                    break;
                }
            }
            if (flag)
            {
                Console.WriteLine("Рецепт удален");
            }
            else
            {
                Console.WriteLine("Такого рецепта не найдено");
            }
            Console.WriteLine("нажмите чтобы продолжить...");
            Console.ReadKey();
        }
    }
}

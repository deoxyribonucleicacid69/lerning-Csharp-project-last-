﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary
{
    /// <summary>
    /// Класс предстваляющий рецепт
    /// </summary>
    public class Recipe
    {
        string name = String.Empty; 
        string category = String.Empty;
        bool isFavorite = false;
        Dictionary<string,string> ingredients = new Dictionary<string,string>();
        List<string> instructions = new List<string>();
        /// <summary>
        /// Конструктор без параметров - инициализирует все поля класса.
        /// </summary>
        public Recipe()
        {
            name = String.Empty;
            category = String.Empty;
            ingredients = new Dictionary<string, string>();
            instructions = new List<string>();
        }
        /// <summary>
        /// Получение названия рецепта
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Получение категории рецепта.
        /// </summary>
        public string Category { get; set; }
        /// <summary>
        /// Получение ингредиентов
        /// </summary>
        public Dictionary<string,string> Ingredients { get; set; }
        /// <summary>
        /// Получение инструкции.
        /// </summary>
        public List<string> Instructions { get; set; }
        /// <summary>
        /// Получение информации о пинадлежности к избранным.
        /// </summary>
        public bool IsFavorite { get; set; } = false;
        /// <summary>
        /// Вывод информации о рецепте.
        /// </summary>
        public void PrintRecipe()
        {
            Console.WriteLine($"Название: {this.Name}");
            Console.WriteLine($"Категория: {this.Category}");
            Console.WriteLine("Ингредиенты:");
            foreach (var ingredient in this.Ingredients)
            {
                Console.WriteLine($"  {ingredient.Key}: {ingredient.Value}");
            }
            Console.WriteLine("Инструкции:");
            foreach (var instruction in this.Instructions)
            {
                Console.WriteLine($"  - {instruction}");
            }
            Console.WriteLine(new string('-', 69));
        }
    }

}

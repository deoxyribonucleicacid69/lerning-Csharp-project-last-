﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Spectre.Console;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace MyLibrary
{
    /// <summary>
    /// Класс для работы с сортировкой списка рецептов
    /// </summary>
    public class ExecuteSorting
    {
        private delegate void EventHandler(ref RecipeList recipeList);
        private List<string> nameOfSort = new List<string>();
        private List<EventHandler> sortHandler = new List<EventHandler>();
        

        /// <summary>
        /// Сортитровка списка рецептов
        /// </summary>
        /// <param name="recipeList"></param>
        public void SotringRecipe(ref RecipeList recipeList)
        {
            if (ServiceClass.isEmptyRecipeList(ref recipeList))
            {
                return;
            }
            int index = 0;

            while (true)
            {
                string[] fieldSortMenu = FieldMenu.SortMenu;
                Menu menu = new Menu();
                menu.PrintMenu(fieldSortMenu, index);
                
                switch (Console.ReadKey(true).Key)
                {
                    case ConsoleKey.DownArrow:
                        if (index < 2)
                            index++;
                        else
                        {
                            index = 0;
                        }
                        break;
                    case ConsoleKey.UpArrow:
                        if (index > 0)
                            index--;
                        else
                        {
                            index = 2;
                        }
                        break;
                    case ConsoleKey.Enter:
                        switch (index + 1)
                        {
                            case 1:
                                Console.WriteLine("Сортировать в от А-Я или от Я-А?");
                                Console.WriteLine("NORMAL-надо ввести чтобы от А-Я,REVERSE- от Я-А");
                                string answer = ServiceClass.GetValidName();
                                if (answer == "NORMAL")
                                {
                                    sortHandler.Add((ref RecipeList recipeList) => { recipeList.Recipes = recipeList.Recipes.OrderBy(p => p.Name).ToList(); });
                                    recipeList.Recipes = recipeList.Recipes.OrderBy(p => p.Name).ToList();
                                    nameOfSort.Add("СОРТИРОВКА ПО НАЗВАНИЮ - NORMAL");

                                }
                                else if(answer == "REVERSE")
                                {
                                    sortHandler.Add((ref RecipeList recipeList) => { recipeList.Recipes = recipeList.Recipes.OrderBy(p => p.Name).ToList();recipeList.Recipes.Reverse(); });

                                    recipeList.Recipes = recipeList.Recipes.OrderBy(p => p.Name).ToList();
                                    recipeList.Recipes.Reverse();
                                    nameOfSort.Add("СОРТИРОВКА ПО НАЗВАНИЮ - REVERSE");


                                }

                                break;
                            case 2:
                                Console.WriteLine("Сортировать в от А-Я или от Я-А?");
                                Console.WriteLine("NORMAL-надо ввести чтобы от А-Я,REVERSE- от Я-А");
                                string answer1 = ServiceClass.GetValidName();
                                if (answer1 == "NORMAL")
                                {
                                    sortHandler.Add((ref RecipeList recipeList) => { recipeList.Recipes = recipeList.Recipes.OrderBy(p => p.Category).ToList(); });
                                    recipeList.Recipes = recipeList.Recipes.OrderBy(p => p.Category).ToList();
                                    nameOfSort.Add("СОРТИРОВКА ПО КАТЕГОРИИ - NORMAL");

                                }
                                else if (answer1 == "REVERSE")
                                {
                                    sortHandler.Add((ref RecipeList recipeList) => { recipeList.Recipes = recipeList.Recipes.OrderBy(p => p.Category).ToList(); recipeList.Recipes.Reverse(); });
                                    recipeList.Recipes = recipeList.Recipes.OrderBy(p => p.Category).ToList();
                                    recipeList.Recipes.Reverse();
                                    nameOfSort.Add("СОРТИРОВКА ПО КАТЕГОРИИ - REVERSE");
                                }
                                else
                                {
                                    Console.WriteLine("Введено некоректное значение");
                                }

                                break;
                            case 3:
                                return;


                        }
                        break;
                }
            }
        }
        

        /// <summary>
        /// Удаление сортировки.
        /// </summary>
        /// <param name="recipeList"></param>
        public void DeleteSorting(ref RecipeList recipeList)
        {
            if (ServiceClass.isEmptyRecipeList(ref recipeList))
            {
                return;
            }
            if (sortHandler.Count == 0)
            {
                Console.WriteLine("Сначала добавте какую нибудь сортировку");
                Console.WriteLine("Нажмите чтобы продолжить");
                return;
            }
            for (int i = 0; i < sortHandler.Count; i++)
            {
                Console.WriteLine($"{i + 1}){nameOfSort[i]}");
            }
            Console.Write("Введите НОМЕР сортировки из списка: ");
            if (int.TryParse(ServiceClass.GetValidName(), out int index))
            {
                sortHandler.Remove(sortHandler[index - 1]);
                nameOfSort.Remove(nameOfSort[index - 1]);
                foreach (var item in sortHandler)
                {
                    item(ref recipeList);
                }
                if (sortHandler.Count() == 0)
                {
                    Console.WriteLine("Вы удалили все сортировки, поэтому чтобы вернуться к стандратному набору");
                    ExecuteReadFile executeReadFile = new ExecuteReadFile();
                    executeReadFile.ReadFile(ref recipeList);
                }
            }
        }
        
    }
}


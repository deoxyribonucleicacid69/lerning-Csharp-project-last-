﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary
{
    public static class ServiceClass
    {
        public static string GetValidName()
        {
            string name = Console.ReadLine();
            while (string.IsNullOrEmpty(name))
            {
                Console.Write("Введено некоректное значение, введите еще раз: ");
                name = Console.ReadLine();
            }
            return name;
        }
        public static bool isEmptyRecipeList(ref RecipeList recipeList)
        {
            if (recipeList.Recipes.Count == 0)
            {
                Console.WriteLine("ERROR:Сначала загрузите данные!!!"); Console.ReadKey();
                return true;
            }
            return false;
        }
    }

}

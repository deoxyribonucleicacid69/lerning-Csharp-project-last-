﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary
{
    /// <summary>
    /// Класс для работы с изменением рецептов
    /// </summary>
    public class ExecuteChange
    {
        /// <summary>
        /// Изменение рецепта
        /// </summary>
        /// <param name="recipeList"></param>
        public void ChangeRecipe(ref RecipeList recipeList)
        {
            ExecutePrintAllRecipe executePrintAllRecipe = new ExecutePrintAllRecipe();
            if (ServiceClass.isEmptyRecipeList(ref recipeList))
            {
                return;
            }
            Menu menu = new Menu();
            string[] changeMenu = FieldMenu.ChangeMenu;
            bool isFindRecipe = false;
            Console.WriteLine("Все рецепты:");
            executePrintAllRecipe.PrintAllecipe(ref recipeList);
            Console.Write("Введите название рецета которые вы хотите изменить: ");
            string recipeName = ServiceClass.GetValidName();
            foreach (Recipe recipe in recipeList.Recipes)
            {
                if (recipeName == recipe.Name)
                {
                    int index = 0;
                    isFindRecipe = true;

                    while (true)
                    {
                        menu.PrintMenu(changeMenu, index);

                        switch (Console.ReadKey(true).Key)
                        {
                            case ConsoleKey.DownArrow:
                                if (index < changeMenu.Length - 1)
                                    index++;
                                else
                                {
                                    index = 0;
                                }
                                break;
                            case ConsoleKey.UpArrow:
                                if (index > 0)
                                    index--;
                                else
                                {
                                    index = 2;
                                }
                                break;
                            case ConsoleKey.Enter:
                                switch (index + 1)
                                {
                                    case 1:
                                        Console.Write("Введите новое название рецепта: ");
                                        recipe.Name = ServiceClass.GetValidName();
                                        Console.WriteLine("нажмите чтобы продолжить...");
                                        Console.ReadKey();
                                        break;
                                    case 2:
                                        Console.Write("Введите новое Категорию рецепта: ");
                                        recipe.Category = ServiceClass.GetValidName();
                                        Console.WriteLine("нажмите чтобы продолжить...");
                                        Console.ReadKey();
                                        break;
                                    case 3:
                                        while (true)
                                        {
                                            Console.Write("Введите ключ (строка): ");
                                            string key = Console.ReadLine();

                                            if (string.IsNullOrEmpty(key))
                                            {
                                                break;
                                            }

                                            Console.Write("Введите значение (число) и через пробел в чем измеряется(мл, кг и так далее): ");
                                            string[] valueInput = Console.ReadLine().Split(' ');
                                            while (!int.TryParse(valueInput[0], out int count))
                                            {
                                                Console.WriteLine("Введено некоректное значение,попробуйте еще раз");
                                                valueInput = Console.ReadLine().Split(' ');

                                            }
                                            recipe.Ingredients[key] = string.Join(" ", valueInput);


                                        }
                                        Console.WriteLine("нажмите чтобы продолжить...");
                                        Console.ReadKey();
                                        break;
                                    case 4:
                                        Console.WriteLine("Введите Интсрукцию(Одна строка один пукнт. Конец пустая строка)");
                                        string instruction = Console.ReadLine();
                                        while (!string.IsNullOrEmpty(instruction))
                                        {
                                            recipe.Instructions.Add(instruction);
                                            instruction = Console.ReadLine();
                                        }
                                        Console.WriteLine("нажмите чтобы продолжить...");
                                        Console.ReadKey();
                                        break;
                                    case 5:
                                        return;
                                }
                                break;
                        }
                    }
                    break;
                }

            }
            if (!isFindRecipe)
            {
                Console.WriteLine("Не удалось найти рецепт");
            }

        }
    }
}

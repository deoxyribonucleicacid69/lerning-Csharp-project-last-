﻿namespace MyLibrary
{
    /// <summary>
    /// Класс предстваляющий список рецептов
    /// </summary>
    public class RecipeList
    {
        /// <summary>
        ///  Конструктор без парметров, инициализирующий лист рецептов.
        /// </summary>
        public RecipeList()
        {
            Recipes = new List<Recipe>();
        }
        /// <summary>
        /// Получение и установления списка рецептов.
        /// </summary>
        public List<Recipe> Recipes { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary
{
    /// <summary>
    /// Класс для работы с добавлением рецепта
    /// </summary>
    public class ExecuteAddRecipe
    {
        /// <summary>
        /// Добавление рецепта
        /// </summary>
        /// <param name="recipeList"></param>
        public void AddRecipe(ref RecipeList recipeList)
        {
            Recipe recipe = new Recipe();
            recipe.Instructions = new List<string>();
            recipe.Ingredients = new Dictionary<string, string>();
            Console.Write("Введите Название рецепта:");
            recipe.Name = ServiceClass.GetValidName();
            Console.Write("Введите категорию блюда: ");
            recipe.Category = ServiceClass.GetValidName();
            Console.WriteLine("Введите Интсрукцию(Одна строка один пукнт. Конец пустая строка)");
            string instruction = Console.ReadLine();
            while (!string.IsNullOrEmpty(instruction))
            {
                recipe.Instructions.Add(instruction);
                instruction = Console.ReadLine();
            }
            Console.WriteLine("Введите ингридиенты и их количество(Конец пуста строка)");
            while (true)
            {
                Console.Write("Введите ключ (строка): ");
                string key = Console.ReadLine();

                if (string.IsNullOrEmpty(key))
                {
                    break;
                }

                Console.Write("Введите значение (число) и через пробел в чем измеряется(мл, кг и так далее): ");
                string[] valueInput = Console.ReadLine().Split(' ');
                while (!int.TryParse(valueInput[0], out int count))
                {
                    Console.WriteLine("Введено некоректное значение,попробуйте еще раз");
                    valueInput = Console.ReadLine().Split(' ');

                }
                recipe.Ingredients[key] = string.Join(" ", valueInput);


            }
            Console.WriteLine("Получился вот такой вот рецепт:");
            recipe.PrintRecipe();
            recipeList.Recipes.Add(recipe);
            Console.WriteLine("нажмите чтобы продолжить...");
            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary
{
    public  static class FieldMenu
    {   
        //Список всех меню
        private static readonly string[] mainMenu = {  "Загрузить рецепты из файла","Все рецепты", "Найти рецепт","Добавить рецепт","Удалить рецепт","Сохранить рецепты в файл","Сортировать рецепты","Статистика","Избранное","Изменить рецепт","Удалить сортировку","Выход" };
        private static readonly string[] sortMenu =  { "Сортировать по названию", "Сортировать по категории", "Выход" };
        private static readonly string[] statistictMenu = { "Количества по каждой категори", "Общее количество рецептов", "Выход" };
        private static readonly string[] changeMenu = ["Измениь название", "Изменить Категорию", "Изменить ингридиенты", "Изменить Интсрукцию", "Выход"];
        private static readonly string[] favoritesMenu = ["Добавить в избранное", "Просмотреть избранное",  "Сохранить избранное в отдельном файле", "Выход"];
        private static readonly string[] searchMenu = ["Поиск по названию", "Поиск по категории", "Поиск по ингидиентам","Комбинированный поиск", "Выход"];






        /// <summary>
        /// Получение главного меню
        /// </summary>
        public static string[] MainMenu
        {
            get { return mainMenu; }
        }
        /// <summary>
        /// Получение меню сортировки
        /// </summary>
        public static string[] SortMenu
        {
            get { return sortMenu; }
        }
        /// <summary>
        /// Получение меню статистики
        /// </summary>
        public static string[] StatistictMenu
        {
            get { return statistictMenu; }
        }
        /// <summary>
        /// Получение меню изменения рецепта
        /// </summary>
        public static string[] ChangeMenu
        {
            get { return changeMenu; }
        }
        /// <summary>
        /// Получение меню избранного
        /// </summary>
        public static string[] FavoritesMenu
        {
            get { return favoritesMenu; }
        }
        /// <summary>
        /// Получение меню поиска рецептов
        /// </summary>
        public static string[] SearchMenu
        {
            get { return searchMenu; }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary
{
    /// <summary>
    /// Класс для работы с выводом списка рецептов.
    /// </summary>
    public class ExecutePrintAllRecipe
    {
        /// <summary>
        /// Вывод списка рецептов.
        /// </summary>
        /// <param name="recipeList"></param>
        public void PrintAllecipe(ref RecipeList recipeList)
        {
            if (ServiceClass.isEmptyRecipeList(ref recipeList))
            {
                return;
            }
            int index = 0;
            foreach (var recipe in recipeList.Recipes)
            {
                if (recipe.IsFavorite) { Console.ForegroundColor = ConsoleColor.Yellow; }
                index++;
                Console.WriteLine($"{index}) {recipe.Name}");
                Console.ResetColor();
            }

        }
    }
}

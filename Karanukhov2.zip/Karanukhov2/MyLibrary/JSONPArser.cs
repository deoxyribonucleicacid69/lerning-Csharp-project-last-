﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Spectre.Console;

namespace MyLibrary
{
    /// <summary>
    /// Класс для работы с JSON файлом
    /// </summary>
    public class JSONPArser
    {
        /// <summary>
        /// Парсинг JSON-файла.
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public RecipeList ParseJSONFile(string filePath)
        {
            RecipeList recipeList = new RecipeList();
            try
            {
                string jsonString = File.ReadAllText(filePath);

                 recipeList = JsonConvert.DeserializeObject<RecipeList>(jsonString) ?? new RecipeList();
                if (recipeList is null || recipeList.Recipes.Count == 0) throw new Exception("Ошибка парсинга файла!!!");
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("Такой файл не найден!!!");
            }
            catch (Exception e)
            {
                Console.WriteLine($"{e.Message}");
            }
            Console.WriteLine("Нажмите чтобы продолжить");
            Console.ReadKey();
            
            return recipeList;
        }
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary
{
    /// <summary>
    /// Класс для работы со статистикой.
    /// </summary>
    public class ExecuteStatistic
    {
        /// <summary>
        /// Вывод разных пунктов статистики.
        /// Количество в каждой категории.
        /// Общеек количество рецептов. 
        /// </summary>
        /// <param name="recipeList"></param>
        public void Statistiс(ref RecipeList recipeList)
        {
            if (ServiceClass.isEmptyRecipeList(ref recipeList))
            {
                return;
            }
            int index = 0;
            while (true)
            {
                string[] fieldSortMenu = FieldMenu.StatistictMenu;
                Menu menu = new Menu();
                menu.PrintMenu(fieldSortMenu, index);

                switch (Console.ReadKey(true).Key)
                {
                    case ConsoleKey.DownArrow:
                        if (index < 2)
                            index++;
                        else
                        {
                            index = 0;
                        }
                        break;
                    case ConsoleKey.UpArrow:
                        if (index > 0)
                            index--;
                        else
                        {
                            index = 2;
                        }
                        break;
                    case ConsoleKey.Enter:
                        switch (index + 1)
                        {
                            case 1:
                                Dictionary<string, int> data = new Dictionary<string, int>();
                                foreach (Recipe recipe in recipeList.Recipes)
                                {
                                    if (data.ContainsKey(recipe.Category))
                                    {
                                        data[recipe.Category] += 1;
                                    }
                                    else
                                    {
                                        data[recipe.Category] = 1;
                                    }
                                }
                                foreach (string key in data.Keys)
                                {
                                    Console.WriteLine($"Количество {key} : {data[key]} ");
                                }
                                Console.WriteLine("нажмите чтобы продолжить...");
                                Console.ReadKey();
                                break;
                            case 2:
                                Console.Write("Общее количество рецептов: ");
                                Console.WriteLine(recipeList.Recipes.Count());
                                Console.WriteLine("нажмите чтобы продолжить...");
                                Console.ReadKey();
                                break;
                            case 3:
                                return;
                        }
                        break;
                }
            }
        }
    }
}

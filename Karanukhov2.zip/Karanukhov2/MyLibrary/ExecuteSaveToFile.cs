﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace MyLibrary
{
    /// <summary>
    /// Класс для работы с сохранением рецептов в файл.
    /// </summary>
    public class ExecuteSaveToFile
    {
        /// <summary>
        /// Сохранение в файл данных.
        /// </summary>
        /// <param name="recipeList"></param>
        public void SaveToFile(ref RecipeList recipeList)
        {
            if (ServiceClass.isEmptyRecipeList(ref recipeList))
            {
                return;
            }
            Console.Write("Введите имя файла, куда сохранить рецепты: ");
            File.WriteAllText(ServiceClass.GetValidName(), JsonConvert.SerializeObject(recipeList));
        }
    }
}

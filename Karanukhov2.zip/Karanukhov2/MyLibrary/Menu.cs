﻿using System;
using Spectre.Console;
using static System.Runtime.InteropServices.JavaScript.JSType;
namespace MyLibrary
{
    /// <summary>
    /// Класс для вывода консольного меню
    /// </summary>
    public class Menu
    {
        /// <summary>
        /// Запуск функционала меню
        /// </summary>
        /// <param name="recipeList"></param>
        public void LaunchingMenu(ref RecipeList recipeList )
        {
            ExecuteSorting executeSorting = new ExecuteSorting(); 
            int index = 0;
            string[] menu = FieldMenu.MainMenu;
            
            while (true)
            {
                PrintMenu(menu, index);
                Console.Write("Количество рецепттов: ");
                Console.ForegroundColor = (recipeList.Recipes.Count >= 1 ? ConsoleColor.Green : ConsoleColor.Red);
                Console.WriteLine((recipeList.Recipes.Count()>0 ? recipeList.Recipes.Count(): 0));
                Console.ResetColor();
                switch (Console.ReadKey(true).Key)
                {
                    case ConsoleKey.DownArrow:
                        if (index < menu.Length - 1)
                            index++;
                        else
                        {
                            index = 0;
                        }
                        break;
                    case ConsoleKey.UpArrow:
                        if (index > 0)
                            index--;
                        else
                        {
                            index = menu.Length - 1;
                        }
                        break;
                    case ConsoleKey.Enter:
                        switch (index + 1)
                        {
                            case 1:
                                ExecuteReadFile executeReadFile = new ExecuteReadFile();
                                executeReadFile.ReadFile(ref recipeList);
                                break;
                            case 2:
                                ExecutePrintAllRecipe executePrintAllRecipe = new ExecutePrintAllRecipe();
                                executePrintAllRecipe.PrintAllecipe(ref recipeList);
                                Console.ReadKey();
                                break;
                            case 3:
                                ExecuteSearch executeSearch = new ExecuteSearch();
                                executeSearch.SearchRecipe(ref recipeList);
                                break;
                            case 4:
                                ExecuteAddRecipe executeAddRecipe = new ExecuteAddRecipe();
                                executeAddRecipe.AddRecipe(ref recipeList);
                                break;
                            case 5:
                                ExecuteDeleteRecipe deleteRecipe = new ExecuteDeleteRecipe();
                                deleteRecipe.DeleteRecipe(ref recipeList);
                                break;
                            case 6:
                                ExecuteSaveToFile executeSaveToFile = new ExecuteSaveToFile();
                                executeSaveToFile.SaveToFile(ref recipeList);
                                break;
                            case 7:
                                executeSorting.SotringRecipe(ref recipeList);

                                break;
                            case 8:
                                ExecuteStatistic executeStatistic = new ExecuteStatistic();
                                executeStatistic.Statistiс(ref recipeList);

                                break;
                            case 9:
                                ExecuteFavorite executeFavorite = new ExecuteFavorite();
                                executeFavorite.FavouritesRecipe(ref recipeList);
                                break;
                            case 10:
                                ExecuteChange executeChange = new ExecuteChange();
                                executeChange.ChangeRecipe(ref recipeList);
                                break;
                            case 11:
                                executeSorting.DeleteSorting(ref recipeList);
                                break;
                            case 12:
                                return;
                        }
                        break;
                }
            }

        }
        /// <summary>
        /// Вывод пунктов меню
        /// </summary>
        /// <param name="fields"></param>
        /// <param name="index"></param>
        public void PrintMenu(string[] fields, int index)
        {
            Console.SetCursorPosition(Console.CursorLeft, Console.CursorTop);//Курсор устанавливаем в левом верхнем углу.
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("===============MENU===============");
            Console.ResetColor();
            for (int i = 0; i < fields.Length; i++)
            {
                if (i == index)//В строке на которой курсор меняем увет текста на черный а задний фон на белый, что выделяет строку
                {
                    Console.Write("->");
                    Console.BackgroundColor = Console.ForegroundColor;
                    Console.ForegroundColor = ConsoleColor.Black;

                }
                Console.WriteLine($"{fields[i]}");
                Console.ResetColor();

            }
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("===============END===============");
            Console.ResetColor();

        }

       
    }
}

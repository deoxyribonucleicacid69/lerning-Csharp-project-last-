﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary
{
    /// <summary>
    /// Класс для работы с поиском рецептов
    /// </summary>
    public class ExecuteSearch
    {
        /// <summary>
        /// Меню работы с поиском.
        /// </summary>
        /// <param name="recipeList"></param>
        public void SearchRecipe(ref RecipeList recipeList)
        {
            if (ServiceClass.isEmptyRecipeList(ref recipeList))
            {
                return;
            }
            Menu menu = new Menu();
            string[] searchMenu = FieldMenu.SearchMenu;
            int index = 0;
            while (true)
            {
                menu.PrintMenu(searchMenu, index);

                switch (Console.ReadKey(true).Key)
                {
                    case ConsoleKey.DownArrow:
                        if (index < searchMenu.Length - 1)
                            index++;
                        else
                        {
                            index = 0;
                        }
                        break;
                    case ConsoleKey.UpArrow:
                        if (index > 0)
                            index--;
                        else
                        {
                            index = searchMenu.Length - 1;
                        }
                        break;
                    case ConsoleKey.Enter:
                        switch (index + 1)
                        {
                            case 1:
                                SearchRecipe(recipeList);
                                break;
                            case 2:
                                SearchCategory(recipeList);
                                break;
                            case 3:
                                Searchingredients(recipeList);
                                break;
                            case 4:
                                SearchCombination(recipeList);
                                break;
                            case 5:
                                return;
                        }
                        break;
                }
            }
        }
        /// <summary>
        /// Комбинированный поиск
        /// </summary>
        /// <param name="recipeList"></param>
        private static void SearchCombination(RecipeList recipeList)
        {
            List<Recipe> recipes = new List<Recipe>();
            Console.WriteLine("Введите название(Пустая строка означает что не искать по названию)");
            string nameRecipe1 = Console.ReadLine();
            if (!string.IsNullOrEmpty(nameRecipe1))
            {
                foreach (Recipe recipe in recipeList.Recipes)
                {
                    if (recipe.Name.Trim().Replace(" ", "").ToLower() == nameRecipe1.Trim().Replace(" ", "").ToLower())
                    {
                        recipes.Add(recipe);
                    }
                }
            }
            else
            {
                recipes.AddRange(recipeList.Recipes);
            }
            List<Recipe> recipes1 = new List<Recipe>();
            List<string> ingredients1 = new List<string>();
            Console.WriteLine("Введите название ингридиентов(пустая строка конец ввода)");
            while (true)
            {
                Console.Write("Введите ключ (строка): ");
                string ingredient = Console.ReadLine();

                if (string.IsNullOrEmpty(ingredient))
                {
                    break;
                }
                ingredients1.Add(ingredient);
            }
            if (ingredients1.Count > 0)
            {
                foreach (Recipe recipe in recipeList.Recipes)
                {
                    foreach (string key in recipe.Ingredients.Keys)
                    {
                        if (ingredients1.Contains(key.ToLower().Replace(" ", "")))
                        {
                            recipes1.Add(recipe);

                        }
                    }
                }
            }
            else
            {
                recipes1.AddRange(recipeList.Recipes);
            }
            List<Recipe> recipes2 = new List<Recipe>();
            Console.Write("Введите название категории(пустая строка означает что не делать поиск по категории): ");
            string category = Console.ReadLine();
            if (string.IsNullOrEmpty(category))
            {
                recipes2.AddRange(recipeList.Recipes);
            }
            else
            {
                foreach (Recipe recipe in recipeList.Recipes)
                {
                    if (recipe.Category.ToLower().Replace(" ", "") == category.ToLower().Replace(" ", ""))
                    {
                        recipes2.Add(recipe);
                    }
                }
            }

            List<Recipe> endRecipes = recipes2.Intersect(recipes.Intersect(recipes1).ToList()).ToList();
            foreach (var recipe in endRecipes)
            {
                recipe.PrintRecipe();
            }
            Console.WriteLine("Нажмите чтобы продолжить");
            Console.ReadKey();
        }
        /// <summary>
        /// Поиск по ингредиментам
        /// </summary>
        /// <param name="recipeList"></param>
        private static void Searchingredients(RecipeList recipeList)
        {
            List<string> ingredients = new List<string>();
            Console.WriteLine("Введите название ингридиентов");
            while (true)
            {
                Console.Write("Введите ключ (строка): ");
                string ingredient = Console.ReadLine();

                if (string.IsNullOrEmpty(ingredient))
                {
                    break;
                }
                ingredients.Add(ingredient.ToLower().Replace(" ", ""));
            }

            foreach (Recipe recipe in recipeList.Recipes)
            {
                foreach (string key in recipe.Ingredients.Keys)
                {
                    if (ingredients.Contains(key.ToLower().Replace(" ", "")))
                    {
                        recipe.PrintRecipe();
                    }
                }
            }
            Console.WriteLine("Нажмите чтобы продолжить");
            Console.ReadKey();
        }
        /// <summary>
        /// Поиск по категории
        /// </summary>
        /// <param name="recipeList"></param>
        private static void SearchCategory(RecipeList recipeList)
        {
            bool isFindRecipe1 = false;
            Console.Write("Введите название категории: ");
            string categoryRecipe = ServiceClass.GetValidName().Trim().Replace(" ", "").ToLower();
            foreach (Recipe recipe in recipeList.Recipes)
            {
                if (recipe.Category.Trim().Replace(" ", "").ToLower() == categoryRecipe)
                {
                    recipe.PrintRecipe();
                    isFindRecipe1 = true;
                }
            }
            if (!isFindRecipe1)
            {
                Console.WriteLine("Рецептов не найден");
            }
            Console.WriteLine("Нажмите чтобы продолжить");
            Console.ReadKey();
        }
        /// <summary>
        /// Поиск по названию.
        /// </summary>
        /// <param name="recipeList"></param>
        private static void SearchRecipe(RecipeList recipeList)
        {
            bool isFindRecipe = false;
            Console.Write("Введите название рецепта: ");
            string nameRecipe = ServiceClass.GetValidName().Trim().Replace(" ", "").ToLower();
            foreach (Recipe recipe in recipeList.Recipes)
            {
                if (recipe.Name.Trim().Replace(" ", "").ToLower() == nameRecipe)
                {
                    recipe.PrintRecipe();
                    isFindRecipe = true;
                }
            }
            if (!isFindRecipe)
            {
                Console.WriteLine("Рецепт не найден");
            }
            Console.WriteLine("Нажмите чтобы продолжить");
            Console.ReadKey();
        }
    }
}

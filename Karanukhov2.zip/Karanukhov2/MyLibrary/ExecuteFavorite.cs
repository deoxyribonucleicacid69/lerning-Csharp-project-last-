﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace MyLibrary
{
    /// <summary>
    /// Класс для работы с избранными рецептами.
    /// </summary>
    public class ExecuteFavorite
    {
        /// <summary>
        /// Метод для работы с избранными рецептами.
        /// Добавление в избранное.
        /// Вывод всех избранный.
        /// Сохранените в файл избранных.
        /// </summary>
        /// <param name="recipeList">Ссылка на список рецептов, который будет отображен.</param>
        public void FavouritesRecipe(ref RecipeList recipeList)
        {
            ExecutePrintAllRecipe executePrintAllRecipe = new ExecutePrintAllRecipe();
            if (ServiceClass.isEmptyRecipeList(ref recipeList))
            {
                return;
            }
            Menu menu = new Menu();
            string[] favoriteMenu = FieldMenu.FavoritesMenu;
            int index = 0;
            while (true)
            {
                menu.PrintMenu(favoriteMenu, index);

                switch (Console.ReadKey(true).Key)
                {
                    case ConsoleKey.DownArrow:
                        if (index < favoriteMenu.Length - 1)
                            index++;
                        else
                        {
                            index = 0;
                        }
                        break;
                    case ConsoleKey.UpArrow:
                        if (index > 0)
                            index--;
                        else
                        {
                            index = favoriteMenu.Length - 1;
                        }
                        break;
                    case ConsoleKey.Enter:
                        switch (index + 1)
                        {
                            case 1:
                                recipeList = AddFavoriteRecipe(ref recipeList, executePrintAllRecipe);
                                break;
                            case 2:
                                PrintFavoriteRecipe(ref recipeList);
                                Console.WriteLine("нажмите чтобы продолжить");
                                Console.ReadKey();
                                break;
                            case 3:
                                SaveFavoriteRecipeInFile(ref recipeList);
                                break;
                            case 4:
                                return;
                        }
                        break;
                }
            }
        }
        /// <summary>
        /// Сохранить список избранных рецептов в файл
        /// </summary>
        /// <param name="recipeList"></param>
        private static void SaveFavoriteRecipeInFile(ref RecipeList recipeList)
        {
            RecipeList favoriteRecipe = new RecipeList();
            favoriteRecipe.Recipes = recipeList.Recipes?.Where(r => r.IsFavorite).ToList() ?? new List<Recipe>();
            Console.WriteLine("Введите имя файла(формат .json): ");
            string nameFile = ServiceClass.GetValidName();
            File.WriteAllText(nameFile, JsonConvert.SerializeObject(favoriteRecipe));
            Console.WriteLine("нажмите чтобы продолжить");
            Console.ReadKey();
        }
        /// <summary>
        /// Вывод всех избранных рецептов
        /// </summary>
        /// <param name="recipeList"></param>
        private static void PrintFavoriteRecipe(ref RecipeList recipeList)
        {
            foreach (Recipe recipe in recipeList.Recipes)
            {
                if (recipe.IsFavorite)
                {
                    recipe.PrintRecipe();
                }
            }
        }
        /// <summary>
        /// Добавление рецепта в избранное
        /// </summary>
        /// <param name="recipeList"></param>
        /// <param name="executePrintAllRecipe"></param>
        /// <returns></returns>
        private static RecipeList AddFavoriteRecipe(ref RecipeList recipeList, ExecutePrintAllRecipe executePrintAllRecipe)
        {
            Console.WriteLine("Все рецепты");
            executePrintAllRecipe.PrintAllecipe(ref recipeList);
            bool isFindRecipe = false;
            Console.Write("Введите имя рецепта которое хотите добавить в избранное: ");
            string recipeName = ServiceClass.GetValidName();
            foreach (Recipe recipe in recipeList.Recipes)
            {
                if (recipe.Name == recipeName)
                {
                    recipe.IsFavorite = true;
                    Console.WriteLine($"Рецепт {recipe.Name} теперь в избранный");
                    isFindRecipe = true;
                }
            }
            if (!isFindRecipe)
            {
                Console.WriteLine("Не удалось найти рецепт");
            }
            Console.WriteLine("нажмите чтобы продолжить...");
            Console.ReadKey();
            return recipeList;
        }
    }
}

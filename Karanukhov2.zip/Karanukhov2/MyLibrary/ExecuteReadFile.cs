﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary
{
    /// <summary>
    /// Класс для работы с чтением файла
    /// </summary>
    public class ExecuteReadFile
    {
        /// <summary>
        /// Чтение файла
        /// </summary>
        /// <param name="recipeList"></param>
        public void ReadFile(ref RecipeList recipeList)
        {
            try
            {
                Console.Write("Введите имя файла: ");
                string filePath = ServiceClass.GetValidName();
                JSONPArser jSONPArser = new JSONPArser();
                recipeList = jSONPArser.ParseJSONFile(filePath);
            }
            catch (Exception e )
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}

﻿using MyLibrary;
using Spectre.Console;
//КАРНАУХОВ БПИ246(1) ВАРИАНТ 3.
class Programm
{
    static void Main(string[] args)
    {
        RecipeList recipeList = new RecipeList();
        recipeList.Recipes = new List<Recipe>();
        Menu menu = new Menu();
        menu.LaunchingMenu(ref recipeList);
    }
}